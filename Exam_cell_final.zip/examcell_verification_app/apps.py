from django.apps import AppConfig


class examcell_verification_appConfig(AppConfig):
    name = 'examcell_verification_app'
